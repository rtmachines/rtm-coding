#![cfg(feature = "model")]
use runtime_bridge::Published;
#[test]
fn publication_model() {
    let mut builder = loom::model::Builder::new();
    builder.checkpoint_interval = 1;
    builder.max_permutations = None;
    builder.max_duration = None;
    builder.preemption_bound = None;
    builder.checkpoint_file = None;
    let executions = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
    let seen = executions.clone();
    builder.check(move || {
        seen.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
        let data = loom::sync::Arc::new(Published::default());
        let writer = data.clone();
        let task = loom::thread::spawn(move || writer.publish(42));
        if let Some(value) = data.snapshot() {
            assert_eq!(value, 42);
        }
        task.join().unwrap();
        assert_eq!(data.snapshot(), Some(42));
    });
    let count = executions.load(std::sync::atomic::Ordering::SeqCst);
    println!("completed model executions: {count}");
    assert!(count > 1);
}
