# Rust review rules

Read by the Codex `rust-pr-review` skill. Adapt the project policy below before
using this template as a merge gate. Existing repository contracts take precedence.

## Severity

| Level | Meaning |
|---|---|
| P0 | Proven critical defect with broad impact: memory unsoundness, data destruction or secret disclosure |
| P1 | Reachable regression, broken contract, deadlock or other defect that must be fixed before merge |
| P2 | Concrete non-blocking correctness, maintainability or measured performance issue |
| P3 | Optional actionable improvement; omit taste-only comments |

Determine priority from reachability, impact and preconditions. A panic, unsafe block,
clone, lint violation or failing command does not automatically establish P0/P1.
Distinguish environment failures and pre-existing failures from defects in the diff.
Each finding needs an exact location, trigger, impact and practical fix. For a deletion,
identify its base-side location explicitly; never invent a current line for missing code.

## Project policy (configure)

- Use the actual edition, MSRV, toolchain, lint levels and error conventions in this repo.
- Review public API compatibility against the project's supported release baseline.
- Check unsafe invariants, aliasing/lifetimes, ownership across FFI and Send/Sync claims.
- Check async blocking, lock order, cancellation, bounded resource use and error paths.
- Require tests for meaningful behavior changes where they protect against regressions.
- Default checks: fmt, clippy, tests (including doctests), cargo-deny with deny.toml.
- Default feature configuration: --all-features. Replace with the supported feature
  matrix for mutually exclusive features; align local checks and CI.
- Configure deny.toml using the project's license, advisory and source policy.
- Only mark deny N/A if project policy explicitly makes it inapplicable; missing
  cargo-deny or deny.toml means NOT RUN. If required evidence is absent, INCOMPLETE.
- Spec PASS requires user requirements or PR acceptance criteria; commit claims alone
  yield PARTIAL. No findings does not mean all requirements were verified.
- Miri and semver-checks are conditional; document applicability and skipped checks.

The skill provides smell, safety and spec references under
`.agents/skills/rust-pr-review/references/`. They inform judgment and do not override
verified source, repository policy or explicit user instructions.

## Fixture project policy

This is an unpublished crate with no dependencies. Required checks: fmt, clippy,
unit tests, doctests and cargo-deny. Requirements are in REQUIREMENTS.md.
No Miri or semver-checks gate applies (no unsafe code; publish=false).
