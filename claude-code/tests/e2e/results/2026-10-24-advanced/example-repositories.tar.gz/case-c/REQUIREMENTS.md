# Vendor callback adapter
Add an RAII adapter for the supported vendor runtime. The Session owns callback
context and unregisters it at destruction, preserving memory safety during teardown.
The SDK extract vendor.h is the available ABI declaration. The vendor binary and
implementation are supplied by the deployment environment and are not in this repo.
