#!/usr/bin/env bash
# Validate a standalone Markdown report from a file or stdin; no hook envelope.
set -euo pipefail
[[ $# -le 1 ]] || { echo 'Usage: check-report.sh [report.md]' >&2; exit 2; }
awk '
function error(message) { print message > "/dev/stderr"; bad=1 }
/^## / {
  section=$0
  if ($0 ~ /^## Verdict: (APPROVE|REQUEST_CHANGES|ESCALATE|INCOMPLETE)$/) {
    verdict=$3; verdict_count++
  }
  seen[$0]++
}
section == "## Gates" && /^- / {
  key=$2; sub(/:$/, "", key); value=$3
  if (key ~ /^(fmt|clippy|tests|doctests|deny)$/) {
    if (gate[key] != "") error("Duplicate gate: " key)
    gate[key]=value
    if (value == "NOT" && $4 == "RUN") gate[key]="NOT RUN"
    if (gate[key] !~ /^(PASS|FAIL|NOT RUN|N\/A)$/) error("Invalid gate status: " key)
    if (value == "N/A" && (key ~ /^(fmt|clippy|tests)$/ || NF < 4)) error("Invalid N/A: " key)
  }
}
section == "## Spec" && /^- spec:/ {
  spec_count++; spec=$3
  if (spec == "NOT" && $4 == "RUN") spec="NOT RUN"
  if (spec !~ /^(PASS|FAIL|PARTIAL|NOT RUN)$/) error("Invalid spec status")
}
section == "## Spec" && /^- (missing|unrequested|contradictions): .+/ { spec_fields[$2]++ }
section == "## Findings" && /^- \[P[0-3]\] / {
  findings++
  if ($0 !~ /[^ ]+:[1-9][0-9]* - .+/) error("Finding missing file:line or explanation")
  if ($2 ~ /\[P[01]\]/) blocking=1
}
section == "## Findings" && /^No findings\.$/ { empty_findings++ }
END {
  if (verdict_count != 1) error("Exactly one valid Verdict required")
  required[1]="## Gates"; required[2]="## Spec"; required[3]="## Findings"; required[4]="## Residual risks"
  for (i=1;i<=4;i++) if (seen[required[i]] != 1) error("Missing/duplicate section: " required[i])
  split("fmt clippy tests doctests deny", names, " ")
  for (i=1;i<=5;i++) {
    key=names[i]
    if (gate[key] == "") error("Missing gate: " key)
    if (verdict == "APPROVE" && gate[key] != "PASS" && gate[key] != "N/A") error("APPROVE requires completed gates: " key)
  }
  if (spec_count != 1) error("Exactly one spec status required")
  split("missing: unrequested: contradictions:", names, " ")
  for (i=1;i<=3;i++) if (spec_fields[names[i]] != 1) error("Missing/duplicate spec field: " names[i])
  if ((!findings && empty_findings != 1) || (findings && empty_findings)) error("Provide findings or No findings., not both")
  if (verdict == "APPROVE" && (spec != "PASS" || blocking)) error("APPROVE conflicts with spec or P0/P1 findings")
  exit bad ? 1 : 0
}' "${1:--}"
