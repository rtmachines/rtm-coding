One writer calls publish exactly once. A concurrent snapshot may return None; if it returns Some, it must equal the published value. Require model exploration of this publication/read protocol.
